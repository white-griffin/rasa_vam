<?php

namespace App\Http\Controllers\Api;

use App\Enums\OrderStatuses;
use App\Enums\PaymentGateways;
use App\Enums\PaymentStatuses;
use App\Helpers\Api\ApiResponse;
use App\Http\Controllers\Controller;
use App\Models\Payment;
use Evryn\LaravelToman\CallbackRequest;
use Evryn\LaravelToman\Facades\Toman;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class PaymentController extends Controller
{

    public function sendToGateway($order,$gateway)
    {
        return match ($gateway) {
            'zarinpal'   => $this->generateZarinpalToken($order),
            'omidpay'    => $this->generateOmidPayToken($order),
            default       => throw new \InvalidArgumentException("درگاه [{$gateway}] پشتیبانی نمی‌شود"),
        };
    }

    public function generateZarinpalToken($order)
    {
        DB::beginTransaction();
        try {
            $request = Toman::amount($order->total_amount)
                ->description($order->orderable->title.' خرید : ')
                ->callback(route('payment.callback'))
                ->request();

            if ($request->successful()) {
                // Store created transaction details for verification
                $transactionId = $request->transactionId();

                $payment = Payment::query()->create([
                    'order_id' => $order->id,
                    'user_id' => $order->user_id,
                    'amount' => $order->total_amount,
                    'transaction_id' => $transactionId,
                ]);

                DB::commit();
                // Redirect to payment URL
                return [
                    'success' => true,
                    'url' => $request->pay()->getTargetUrl(),
                ];
            }

            DB::commit();
            if ($request->failed()) {
                // Handle transaction request failure.
                return [
                    'success' => false,
                    'message' => $request->message(),
                ];
            }

        }catch (\Exception $exception){
            DB::rollBack();
            return [
                'success' => false,
                'message' => $exception->getMessage(),
            ];
        }
    }

    public function callbackZarinpalGateway(CallbackRequest $request){

        DB::beginTransaction();
        try {

            $paymentRecord = Payment::where('transaction_id',$request->transactionId())
                ->with('order')
                ->first();
            $payment = $request->amount($paymentRecord->amount)->verify();

            if ($payment->successful()) {

                // Store the successful transaction details
                $refId = $payment->referenceId();

                $paymentRecord->update([
                    'reference_id' => $refId,
                    'payment_status' => OrderStatuses::PAID->value,
                    'paid_at' => now()->timestamp,
                ]);
                $paymentRecord->order->update([
                    'order_status' => OrderStatuses::PAID->value,
                    'paid_at' => now()->timestamp,
                ]);

                $paymentRecord->order->orderable->purchaseCompleted();

                DB::commit();
                return view('user.payments.success-pay');
            }

            if ($payment->alreadyVerified()) {
                DB::commit();
                return view('user.payments.already-payed');
            }

            if ($payment->failed()) {
                $paymentRecord->update([
                    'payment_status' => OrderStatuses::FAILED->value,
                ]);
                $paymentRecord->order->update([
                    'payment_status' => OrderStatuses::FAILED->value,
                ]);
                DB::commit();
                return view('user.payments.failed-pay');
            }
            DB::commit();
        }catch (Exception $e){
            DB::rollBack();
            return view('user.payments.failed-pay');
        }

    }


    public function generateOmidPayToken($order)
    {
        $url = 'https://ref.omidpayment.ir/ref-payment/RestServices/mts/generateTokenWithNoSign/';

        $data = [
            "WSContext" => [
                "UserId" => "411523672",
                "Password" => "788003"
            ],
            "TransType" => "EN_GOODS",
            "ReserveNum" => $order->order_number,
            "MerchantId" => "411523672",
            "TerminalId" => "41856066",
            "Amount" => $order->total_amount,
            "ProductId" => "", // در صورت نیاز پر شود
            "GoodsReferenceID" => "987654",
            "MerchatGoodReferenceID" => "111",
            "MobileNo" => $order->user->mobile,
            "Email" => $order->user->email ?? "mohamadamin.zanguee@rasavam.com",
            "RedirectUrl" => route('payment.omidpay.callback') // این URL را با URL مورد نظر خود جایگزین کنید
        ];

        DB::beginTransaction();
        try {
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
                // اگر نیاز به هدر دیگری بود، اینجا اضافه کنید
            ])->post($url, $data);

            $responseData = $response->json(); // یا $response->body() برای دریافت رشته خام

            // بررسی وضعیت پاسخ
            if ($response->successful() && $responseData['Result'] == 'erSucceed') {
                // پاسخ موفقیت آمیز بود

                // اینجا $responseData حاوی اطلاعاتی است که از API دریافت کرده‌اید
                // مثلاً توکن تولید شده
                $payment = Payment::query()->create([
                    'order_id' => $order->id,
                    'gateway' => PaymentGateways::OMIDPAY->value,
                    'amount' => $order->total_amount,
                    'authority' => $responseData['token'],
                    'transaction_id' => $order->order_number
                ]);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'url' => 'https://omid.shaparak.ir/_ipgw_/merchant/token',
                    'token' => $responseData['token'],
                ]);

            } else {
                // پاسخ خطا بود (مثلاً 4xx یا 5xx)
                $statusCode = $response->status();
                $errorBody = $response->json(); // یا $response->body()

                $payment = Payment::query()->create([
                    'order_id' => $order->id,
                    'amount' => $order->total_amount,
                    'gateway' => PaymentGateways::OMIDPAY->value,
                    'payment_status' => PaymentStatuses::FAILED->value,
                    'transaction_id' => $order->order_number,
                    'gateway_response' => $errorBody
                ]);

                DB::commit();
                return response()->json([
                    'success' => false,
                    'message' => "API request failed with status {$statusCode}.",
                    'error' => $errorBody
                ], $statusCode);
            }

        } catch (\Exception $e) {
            DB::rollBack();
            // خطای در حین اجرای درخواست (مثلاً خطای شبکه)
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while making the API request.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function callbackOmidPay(Request $request)
    {
        DB::beginTransaction();
        try {
            $payment = Payment::query()
                ->where('order_number',$request->ResNum)
                ->first();

            if ($request->State == 'OK'){
                $payment->update([
                    'reference_id' => $request->RefNum,
                    'gateway_response' => $request->all(),
                    'paid_at' => now()->timestamp
                ]);
                DB::commit();
                $this->verifyOmidPay($request->RefNum,$payment->authority);
            }
        }catch (\Exception $e){
            DB::rollBack();
        }
    }
    public function verifyOmidPay($refNum,$token)
    {
        $url = 'http://ref.sayancard.ir/ref-payment/RestServices/mts/verifyMerchantTrans/';

        $data = [
            "WSContext" => [
                "UserId" => "411523672",
                "Password" => "788003"
            ],
            "RefNum" => $refNum,
            "Token" => $token,
        ];

        DB::beginTransaction();
        try {
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post($url, $data);

            $responseData = $response->json();
            $payment = Payment::query()
                ->where('authority',$token)
                ->first();

            // بررسی وضعیت پاسخ
            if ($response->successful() && $responseData['Result'] == 'erSucceed') {
                // پاسخ موفقیت آمیز بود

                $payment->update([
                    'payment_status' => PaymentStatuses::SUCCESS->value,
                ]);

                DB::commit();
                return ApiResponse::Success('پرداخت موفق');

            } else {
                // پاسخ خطا بود (مثلاً 4xx یا 5xx)
                $statusCode = $response->status();
                $errorBody = $response->json(); // یا $response->body()

                $payment->update([
                    'payment_status' => PaymentStatuses::FAILED->value,
                    'gateway_response' => [
                        'status' => $statusCode,
                        'error' => $errorBody
                    ]
                ]);
                DB::commit();
                return ApiResponse::Fail($statusCode, 'خطا در پرداخت');

            }

        } catch (\Exception $e) {
            DB::rollBack();
            return ApiResponse::Fail(Response::HTTP_INTERNAL_SERVER_ERROR, $e->getMessage());
        }
    }

}
