<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServicePrice extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'items' => 'array',
    ];
}
